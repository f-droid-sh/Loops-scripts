#!/bin/bash
#loop_for_07
read -p "Tell me the number of your house: " house
for n in $house; do
	let num=$house%2
	if [ $num -eq 0 ]; then
		echo "Your house is on the left"
	else
		echo "Your house is on the rigth"
	fi
done

exit 0

