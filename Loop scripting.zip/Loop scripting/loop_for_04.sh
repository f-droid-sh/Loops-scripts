#!/bin/bash
#Loop 04
for n in $(seq 0 17); do
	echo ""
	echo ""
	for m in $(seq 1 10); do
		let rest=n*m
		echo $n*$m"="$rest
	done
	echo ""
done

exit 0
