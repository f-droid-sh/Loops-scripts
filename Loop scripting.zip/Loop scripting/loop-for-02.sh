#!/bin/bash
#loop 02
for n in $(seq 1 500); do
	let res=$n*13
	if [ $res -le 500 ]; then
	   echo $res

	fi

done

exit 0
