#!/bin/bash
#loop for 03
for n in $(ls /var/log | grep ^[azrds]); do
	echo $n

done

exit 0

