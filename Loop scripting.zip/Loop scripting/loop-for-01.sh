#!/bin/bash
# loop 01
read -p "Tell me the number: " num
for n in $(seq 1 10); do
	let mult=$num*$n
	echo $num*$n"="$mult

done

exit 0


