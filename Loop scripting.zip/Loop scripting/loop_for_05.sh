#!/bin/bash
#Loop_for_05
p=1
for n in $(seq 1 1000); do
	let sum=n+p
	echo $n+$p"="$sum
done

exit 0
