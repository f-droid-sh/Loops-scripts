#!/bin/bash
#loop_for_06
for n in $(seq 0 50); do
	let mul=2*$n+1
	if [ $mul -le 49 ]; then
		echo $mul
	fi
done

exit 0
