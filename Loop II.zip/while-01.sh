#!/bin/bash
read -p "Dime un número: " num
	while [ $num -lt 100 ]; do
		let num=num*2
		echo " "$num
	done

exit 0
