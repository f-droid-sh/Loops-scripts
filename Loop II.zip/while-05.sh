#!/bin/bash
#palabra focal en la ruta
leer=`cat /etc/apt/sources.list | grep "focal"`
echo $leer

exit 0
