#!/bin/bash
#Escribe sí o no
read -p "Escribe (Sí/No)" bucle
while [ $bucle = "Sí" ]; do
	echo "Me encantan los bucles"
	read -p "Escribe (Sí/No)" bucle
done
echo "Qué pena, una persona aburrida..."
exit 0
