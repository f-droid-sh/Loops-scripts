#!/bin/bash
#Path to file
varnum=0
let varn=varn+varnum
touch /tmp/Im-growing-with-text
while [ $varn -le 0 ]; do
	varnum=$(ls -s /tmp/Im-growing-with-text | cut -d " " -f1)
	let varn=varnum	
	if [ $varn -ge 1 ]; then
		echo "The file contain characters"
	else
		echo "The file not contain characters"
		sleep 2
	fi
done
rm /tmp/Im-growing-with-text

exit 0

