#!/bin/bash
read -p "Dime un número: " num
	while [ $num -lt 1000 ]; do
		let num=num+123
		echo " "$num
	done

exit 0
