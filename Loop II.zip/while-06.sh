#!/bin/bash
stop=0
fiche='/tmp/if-I-exist-exist-I-stop'

while [ $stop -le 1 ]; do
	if [ -f $fiche ]; then
	let stop=stop+1
	elif [ -d $fiche ]; then
	let stop=stop+1
	else
		echo "Espere hasta que el fichero junto con la ruta sean creados."
	sleep 2
	fi
done
echo "Ya lo tengo"

exit 0
