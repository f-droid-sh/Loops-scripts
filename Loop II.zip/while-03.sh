#!/bin/bash
#Bucle 3
varnum=200
while [ $varnum -gt 100 ]; do
	read -p "Dime un número " varnum
done
let varnum=varnum*42
toilet $varnum
exit 0
