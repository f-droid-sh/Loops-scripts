#!/bin/bash
clear
var1=0
#Marcamos la ruta que vamos a comprobar
Ruta1='/proc/'
figlet Te muestro los procesos
#Le indicamos al usuario que vamos a hacer
echo "Para deterlo pulsamos CTRL + C"
while [ $var1 = 0 ]; do
	proceso=$(ls $Ruta1 | wc -l)
	#Calculamos el números de procesos
	if [ $proceso -ge 2000 ]; then
		echo "Pruebas" $Ruta1 ": "$proceso "-> Peligro"
		#Le mostramos el número de procesos y indicamos si es excesivo
		sleep 10
	else
		echo "Pruebas" $Ruta1 ": "$proceso "-> OK"
		sleep 10
	fi
done

exit 0
