#!/bin/bash
clear
#Aquí tenemos la ruta donde vamos a ver los usuarios
Ruta1='/home'
Ruta2='/root/'
figlet Te muestro los usuarios
#Si cumple entramos
for dir in $(ls $Ruta1); do
	ruta01=$Ruta1"/"$dir
	b=$(du -sb $ruta01 | cut -f1)
	echo "ruta: "$ruta01 "tamaño: " $b
	sleep 2
	#Si es mayor que 100000 entra
	if [ $b -gt 100000000 ]; then
		#Mostramos si se ha excedido junto con la cntidad restante
		echo $Ruta1 "El tamaño se ha excedido: "$b
		sleep 2
	else
		echo $Ruta1 "El tamaño es correcto "$b
	fi
done
echo ""
by=$(du -sb $Ruta2 | cut -f1)
echo "ruta: "$Ruta2 "tamaño: "$by
#Hacemos el mismo procedimiento pero con el /root/
sleep 2
if [ $by -gt 100000000 ]; then
	echo $Ruta2 "El tamaño se ha excedido: "$by
else
	echo $Ruta2 "El tamaño es correcto "$by
fi


exit 0
