#!/bin/bash
cable=0
w=0
while [ $cable != "q" ];do
#Cuando sea distinto de "q" tiene que entrar en el bucle
echo "=== Opciones ==="
echo "###############"
echo "Directo --> d #"
echo "###############"
echo "Cruzado --> c #"
echo "###############"
echo "Salida --> q  #"
echo "###############"
read -p "Dime que cable quieres ver: " cable
#Le preguntamos al usuario el tipo de cable que quiere ver y se lo mostramos
	if [ $cable = "d" ];then
		echo "Primera punta: "
		echo ""
		sleep 0.5
		echo -e "Blanco naranja"
		sleep 0.5
		echo "Naranja"
		sleep 0.5
		echo "Blanco verde"
		sleep 0.5
		echo "Azul"
		sleep 0.5
		echo "Blanco Azul"
		sleep 0.5
		echo "Verde"
		sleep 0.5
		echo "Blanco marrón"
		sleep 0.5
		echo "Marrón"
		sleep 0.5
		echo ""
		echo "Segunda punta: "
		echo ""
		sleep 0.5
		echo "Blanco naranja"
		sleep 0.5
                echo "Naranja"
		sleep 0.5
                echo "Blanco verde"
		sleep 0.5
                echo "Azul"
		sleep 0.5
                echo "Blanco Azul"
		sleep 0.5
                echo "Verde"
		sleep 0.5
                echo "Blanco marrón"
		sleep 0.5
                echo "Marrón"
		echo ""
		echo ""

	fi
	if [ $cable = "c" ];then
		echo "Primera punta: "
		echo ""
		sleep 0.5
		echo "Blanco verde"
		sleep 0.5
		echo "Verde"
		sleep 0.5
		echo "Blanco naranja"
		sleep 0.5
		echo "Azul"
		sleep 0.5
		echo "Blanco azul"
		sleep 0.5
		echo "Naranja"
		sleep 0.5
		echo "Blanco marrón"
		sleep 0.5
		echo "Marrón"
		sleep 0.5
		echo ""
		echo "Segunda punta: "
		echo ""
		sleep 0.5
		echo "Blanco naranja"
		sleep 0.5
                echo "Naranja"
		sleep 0.5
                echo "Blanco verde"
		sleep 0.5
                echo "Azul"
		sleep 0.5
                echo "Blanco Azul"
		sleep 0.5
                echo "Verde"
		sleep 0.5
                echo "Blanco marrón"
		sleep 0.5
                echo "Marrón"
		echo ""
		echo ""
	fi
	let w=w+1
done
echo "Alabanza a Javier y sus enseñanzas, hemos consultado Number_of_wires "$w
#Para finalizar, lanzamos un mensaje gracioso :)
exit 0
