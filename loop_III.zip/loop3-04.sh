#!/bin/bash
clear
read -p "Dime el número de la base: " base
read -p "Dime el número del multiplicando: " mult
read -p "Dime el número de repeticiones: " reps
#Le preguntamos al usuario los siguientes datos, después realizamos la operacion
let res=base*mult
for n in $(seq 1 $reps); do
	echo "El resultado es: "$res
#En este bucle mostramos la cantidad de veces que nos ha dicho el usuario el resultado
done

exit 0
