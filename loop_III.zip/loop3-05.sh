#!/bin/bash
modelo=0
tuvas=0
clear
while [ $modelo != "q" -o $tuvas != "q" ]; do
#Le decimos con un while que si es distinto de "q" que entre en el bucle
echo "#######################"
echo "Model Titan --> t     #"
echo "#######################"
echo "Model Pachyderm --> p #"
echo "#######################"
echo "Model Albatros --> to #"
echo "#######################"
echo "Key to exit --> q     #"
echo "#######################"
echo ""
sleep 0.4
read -p "Dime el modelo que quieres elegir: " modelo
echo ""
sleep 0.5
read -p "Dime las toneladas que tienes de uvas: " tuvas
echo ""
#Le hacemos al usuario dos preguntas para poder calcularlo
	let uvas=tuvas*1000
	if [ $modelo = "t" ]; then
		let totaltitan=uvas/1200
		let c=totaltitan*1200
		#Sacamos los kg de las toneladas que nos ha dicho el usuario, y posteriormente calculamos los vagones
		if [ $c -le $uvas ]; then
			let totaltitan=totaltitan+1
		fi
		sleep 0.5
		echo "Con estas: "$tuvas " toneladas se pueden llenar --> "$totaltitan " vagones"
		echo ""
	fi
	if [ $modelo = "p" ]; then
		let totalpaquidermo=uvas/900
		let d=totalpaquidermo*900
		#Calculamos los vagones y se los mostramos al usuario
		if [ $d -le $uvas ]; then
			let totalpaquidermo=totalpaquidermo+1
		fi
		sleep 0.5
		echo "Con estas: "$tuvas "toneladas se pueden llenar --> "$totalpaquidermo " vagones"
		echo ""
	fi
	if [ $modelo = "to" ]; then
		let totalalbatros=uvas/300
		let e=totalalbatros*300
		#Calculamos los vagones y se lo mostramos al usuario
		if [ $e -le $uvas ]; then
			let totalalbatros=totalalbatros+1
		fi
		sleep 0.5
		echo "Con estas "$tuvas "toneladas se pueden llenar -->" $totalalbatros " vagones"
		echo ""
	fi

done

exit 0
